<?php
	if(isset($_POST['btn']))
	{
	header("location:hompage.php");
	}
?>
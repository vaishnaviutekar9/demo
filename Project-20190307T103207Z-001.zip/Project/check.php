<?php
session_start();
if(isset($_SESSION['UID'])){
	echo "<script type='text/javascript'>location.href='post.php'</script> ";
}else{
	echo "<script type='text/javascript'>location.href='L.php'</script> ";
}
?>
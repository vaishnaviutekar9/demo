<?php
session_start();

?>
<html>
<head>
<title>
Error-page
</title>
</head>
<body>
<div class="form">
<h1>Error</h1>
<p>
<?php
if(isset($_SESSION['message'])AND !empty($_SESSION['message'])):
echo $_SESSION['message'];
else:
header("url:homepage.php");
endif;
?>
</p>
</body>
</html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="Logincss.css">
<title>VLinkU</title>
</head>
<style>
</style>
<body>
<div class="login-box">
<h1>Login</h1>
<div class="textbox">
<form method="post" action="Log.php">
<i> <img src="user.png"></i>
<input type="text" placeholder="User ID" name="UID" value="">
</div>
<div class="textbox">
<i><img src="lock.jpg"></i>
<input type="password" placeholder="*******" name="password" >
</div>
<input class="btn" type="submit" name="LoginBtn" value="SignIn">
</div>
</form>
<div class="Forgot">
<a href="">Forgot Password</a>
</div>
</body>
</html>
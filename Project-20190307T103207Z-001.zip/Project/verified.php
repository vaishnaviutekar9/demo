<?php
session_start();
require_once('../connect.php');
$email=$_SESSION['Vmail'];
if(mysqli_query($conn,"INSERT INTO email_verify (Email,verified)VALUES('$email',1)"))
{
	header("location:z.html");
}	
?>
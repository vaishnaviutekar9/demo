<?php
require_once('../connect.php');
session_start();
if(isset($_GET['emailid'])&&!empty($_GET['emailid']))
{
$email=mysqli($_GET['email']);
$result=$mysqli->query("SELECT * FROM registration_details WHERE Email='$emailid'");
if($result->num_rows==0)
{
$_SESSION['message']="Account has already been activated";
header("url:error.php");
}
else
{
$_SESSION['message']="Your account has been activated";
$_SESSION['active']=1;
header("url:success.php");
}
}
else{
$_SESSION['message']="Invalid parameters for account verifiaction";
}
?>
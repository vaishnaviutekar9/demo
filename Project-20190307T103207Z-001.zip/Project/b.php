<?php
session_start();
require_once('../a.php');
$nam=$name;
echo "$nam";
?>
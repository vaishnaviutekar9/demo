<?php
session_start();
echo "hello";
$name='kunal';
$_SESSION[$name]=1;
echo "$_SESSION[$name]";


?>
<?php
echo"Hello";
$user='root';
$password='';
$db='demo';
$database=newmysqli('localhost','$user','$password','$db') or die("unable to connect");
echo"done";




?>